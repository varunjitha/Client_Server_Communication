import json
import urllib.request
import urllib.error

SERVER_URL = "http://localhost:5000/upload"
UPDATE_FILE = "client_updates.json"

def send_update(client_id, update):
    payload = json.dumps({
        "client_id": str(client_id),
        "update": update
    }).encode("utf-8")

    request = urllib.request.Request(
        SERVER_URL,
        data=payload,
        headers={"Content-Type": "application/json"},
        method="POST"
    )

    try:
        with urllib.request.urlopen(request, timeout=10) as response:
            result = json.loads(response.read().decode("utf-8"))
            print(f"Client {client_id}: {result['message']}")

    except urllib.error.URLError as e:
        print(f"Client {client_id}: connection failed - {e}")
        print("Make sure server.py is running first.")

def main():
    with open(UPDATE_FILE, "r", encoding="utf-8") as f:
        updates = json.load(f)

    print("Starting Varunjitha client-to-server communication...")
    print(f"Loaded {len(updates)} packaged client updates.")

    for client_id, update in updates.items():
        send_update(client_id, update)

    print("Communication process completed.")

if __name__ == "__main__":
    main()
