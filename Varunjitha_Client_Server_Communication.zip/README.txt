# Varunjitha - Client-to-Server Communication

## Role
Varunjitha's module receives Swathi's packaged client model updates and sends
them from the edge clients to the Federated Learning server.

## Flow

Swathi S
  -> packaged client updates
  -> Varunjitha client.py
  -> HTTP POST
  -> server.py (FL Server, port 5000)
  -> next Federated Learning / aggregation stage

## Important
Swathi's package format contains:
- trees
- n_features_in_
- n_samples

The current communication module does NOT perform:
- local model training
- model packaging
- FedAvg aggregation
- encryption

Those are separate project stages.

## Step 1: Prepare Swathi's output

The client expects a file named:

client_updates.json

Format:

{
  "1": {
    "trees": [...],
    "n_features_in_": 38,
    "n_samples": 123
  },
  "2": {
    "trees": [...],
    "n_features_in_": 38,
    "n_samples": 120
  },
  "3": {
    "trees": [...],
    "n_features_in_": 38,
    "n_samples": 125
  },
  "4": {
    "trees": [...],
    "n_features_in_": 38,
    "n_samples": 121
  }
}

Use Swathi's REAL packaged updates here. Do not use the demo file for
the final project.

## Step 2: Start the server

Open Terminal 1:

python server.py

Expected:

FL Server running on port 5000...
Waiting for client model updates...

Keep this terminal running.

## Step 3: Run Varunjitha's client

Open Terminal 2:

python client.py

Expected:

Starting Varunjitha client-to-server communication...
Loaded 4 packaged client updates.
Client 1: Client 1 update received
Client 2: Client 2 update received
Client 3: Client 3 update received
Client 4: Client 4 update received
Communication process completed.

## Step 4: Check the server

The server should show:

Client 1: update received ...
Client 2: update received ...
Client 3: update received ...
Client 4: update received ...

## No external package is required

This project uses only Python standard-library modules.
You do NOT need to install requests.

Recommended Python command on Windows:

py server.py

and in another terminal:

py client.py

## Demo test

If you do not have Swathi's real JSON file yet:

py make_demo_data.py

Then rename/copy client_updates_demo.json to client_updates.json
and run the server and client.

The demo only verifies communication. It is NOT a real trained model update.
