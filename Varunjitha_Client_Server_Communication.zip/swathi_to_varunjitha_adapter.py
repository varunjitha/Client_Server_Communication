import json
from pathlib import Path

def save_packaged_updates(updates, output_file="client_updates.json"):
    """
    Save the dictionary returned by Swathi's package_all_client_updates()
    into the JSON format expected by Varunjitha's client.py.

    Call this from Swathi's packaging script after:
        updates = package_all_client_updates()
    """
    serializable = {str(client_id): update for client_id, update in updates.items()}

    with open(output_file, "w", encoding="utf-8") as f:
        json.dump(serializable, f, indent=2)

    print(f"Saved {len(serializable)} client updates to {output_file}")

if __name__ == "__main__":
    print("Import save_packaged_updates() from this file in Swathi's packaging stage.")
