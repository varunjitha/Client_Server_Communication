import json

# Creates a small DEMO package only for testing communication.
# Replace client_updates.json with Swathi's real packaged updates
# before doing the actual project run.

demo = {}

for client_id in range(1, 5):
    demo[str(client_id)] = {
        "trees": [
            {
                "max_depth": 1,
                "node_count": 1,
                "nodes": [],
                "values": []
            }
        ],
        "n_features_in_": 38,
        "n_samples": 100
    }

with open("client_updates_demo.json", "w", encoding="utf-8") as f:
    json.dump(demo, f, indent=2)

print("Created client_updates_demo.json")
print("This is DEMO data. Do not use it as the final ML model update.")
