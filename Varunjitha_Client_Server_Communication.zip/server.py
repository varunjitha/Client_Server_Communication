import json
from http.server import BaseHTTPRequestHandler, HTTPServer

HOST = "localhost"
PORT = 5000

received_updates = {}

class FLServer(BaseHTTPRequestHandler):
    def _send_json(self, status, data):
        body = json.dumps(data).encode("utf-8")
        self.send_response(status)
        self.send_header("Content-Type", "application/json")
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def do_POST(self):
        if self.path != "/upload":
            self._send_json(404, {"status": "error", "message": "Unknown endpoint"})
            return

        try:
            length = int(self.headers.get("Content-Length", 0))
            raw = self.rfile.read(length)
            data = json.loads(raw.decode("utf-8"))

            client_id = str(data.get("client_id"))
            update = data.get("update")

            if client_id not in {"1", "2", "3", "4"}:
                self._send_json(400, {"status": "error", "message": "Invalid client_id"})
                return

            if not isinstance(update, dict):
                self._send_json(400, {"status": "error", "message": "update must be an object"})
                return

            required = {"trees", "n_features_in_", "n_samples"}
            missing = required - set(update.keys())
            if missing:
                self._send_json(
                    400,
                    {"status": "error", "message": f"Missing fields: {sorted(missing)}"}
                )
                return

            received_updates[client_id] = update

            print(
                f"Client {client_id}: update received | "
                f"{len(update['trees'])} trees | "
                f"{update['n_features_in_']} features | "
                f"{update['n_samples']} samples"
            )

            self._send_json(
                200,
                {
                    "status": "success",
                    "message": f"Client {client_id} update received",
                    "client_id": client_id
                }
            )

        except Exception as e:
            self._send_json(400, {"status": "error", "message": str(e)})

    def do_GET(self):
        if self.path == "/status":
            self._send_json(
                200,
                {
                    "status": "running",
                    "received_clients": sorted(received_updates.keys())
                }
            )
        else:
            self._send_json(404, {"status": "error", "message": "Unknown endpoint"})

if __name__ == "__main__":
    print(f"FL Server running on port {PORT}...")
    print("Waiting for client model updates...")
    print("POST endpoint: http://localhost:5000/upload")
    print("Status endpoint: http://localhost:5000/status")
    HTTPServer((HOST, PORT), FLServer).serve_forever()
